import invertArrayDictionary from '../../utils/invertArrayDictionary';
import AltedKeysDictionary from '../AltedKeysDictionary';

const UnaltedKeysDictionary = invertArrayDictionary(AltedKeysDictionary);

export default UnaltedKeysDictionary;
