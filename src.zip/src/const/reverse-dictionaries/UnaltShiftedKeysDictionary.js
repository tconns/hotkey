import invertArrayDictionary from '../../utils/invertArrayDictionary';
import AltShiftedKeysDictionary from '../AltShiftedKeysDictionary';

const UnaltShiftedKeysDictionary = invertArrayDictionary(AltShiftedKeysDictionary);

export default UnaltShiftedKeysDictionary;
