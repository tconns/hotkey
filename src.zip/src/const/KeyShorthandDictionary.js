/**
 * A mapping between key names and official names
 */
const KeyShorthandDictionary = {
  'cmd': 'Meta',
};

export default KeyShorthandDictionary;
