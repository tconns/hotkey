const ModifierFlagsDictionary = {
  Shift: [ 'shiftKey' ],
  Meta: [ 'metaKey' ],
  Control: [ 'ctrlKey' ],
  Alt: [ 'altKey' ]
};

export default ModifierFlagsDictionary;
