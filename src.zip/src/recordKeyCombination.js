import KeyEventManager from './lib/KeyEventManager';

/**
 * @callback keyCombinationListener
 */

function contains(collection, item, options = {}) {
  if (Array.isArray(collection) || isString(collection)) {
    return findableCollectionContains(collection, item, options);
  }

  if (isObject(collection)) {
    return hasKey(collection, item);
  }

  return nonCollectionContains(collection, item, options);
}

/**
 * Adds a listener function that will be called the next time a key combination completes
 * @param {keyCombinationListener} callbackFunction Listener function to be called
 * @returns {function} Function to call to cancel listening to the next key combination
 */
function recordKeyCombination(callbackFunction) {
  const eventManager = KeyEventManager.getInstance();

  return eventManager.addKeyCombinationListener(callbackFunction);
}

export default recordKeyCombination;
