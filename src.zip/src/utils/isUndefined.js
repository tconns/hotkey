function isUndefined(object) {
  return typeof object === 'undefined';
}

export default isUndefined;
