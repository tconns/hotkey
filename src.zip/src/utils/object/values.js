export default object => Object.keys(object).map(key => object[key]);
