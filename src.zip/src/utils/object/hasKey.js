function hasKey(object, key) {
  return object.hasOwnProperty(key);
}

export default hasKey;
