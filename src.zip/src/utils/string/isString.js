function isString(object) {
  return typeof object === 'string';
}

export default isString;
