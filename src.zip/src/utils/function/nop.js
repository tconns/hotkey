function nop(element) { return element; }

export default nop;
